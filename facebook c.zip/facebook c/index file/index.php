<?php

session_start();

if (isset ($_SESSION['first_name'])) {
	header('location: home/home.php');
}


?>
<!doctype html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />

		<!-- Responsive Css -->
		<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all" />

		<!-- Style Css -->
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />

		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
		
		<!-- Title Icon -->
		 <link rel="shortcut icon" type="x-icon" href="img/title.ico"/>

		<title>Facebook</title>
	</head>
	<body>
			<!--[if IE]>
			<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
			<![endif]-->
			<!-- Header area Started from here -->
		
		<section class="container-fluid header_area">
			<div class="container">
				<header class="row">
					<div class="col-lg-3 col-md-6 logo">
						<a  href="#">Facebook</a>
					</div>
					<div class="col-lg-9 col-md-6 login_area">
						<form class="d-sm-flex justify-content-lg-end justify-content-sm-center form_login" action="inc/login.php" method="post">
							<div class="mr-sm-3">
								<label for="email">Email or Phone</label>
								<input type="text" name="email" id="email">
							</div>
							<div class="">
								<label for="password">Password</label>
								<input type="password" name="password" id="password">
								<a href="#" class="d-block">Forgotten account?</a>
							</div>
							<div class="submit">
								<input type="submit" value="Login">
							</div>					
						</form>
					</div>
				</header>
			</div>
		</section>

			<!-- Header area End from here -->
			<!-- Main area Started from here -->

			<!-- error message -->

			<?php

			if (isset($_GET['result']) ) {

			
				if ($_GET['result'] == 'empty-box') {
					echo '<h1 style="background:red;color:#fff; text-align:center;padding:20px; margin:0; ">Empty input</h1>';
				}

				elseif ($_GET['result'] == 'Already-You-have-an-account') {
					echo '<h1 style="background:red;color:#fff; text-align:center;padding:20px; margin:0; ">Already You have an account</h1>';
				}

				elseif ($_GET['result'] == 'Your-email-is-not-math') {
					echo '<h1 style="background:red;color:#fff; text-align:center;padding:20px; margin:0; ">Your email is not math</h1>';
				}
				elseif ($_GET['result'] == 'ok') {
					echo '<h1 style="background:green;color:#fff; text-align:center;padding:20px; margin:0; ">Welcome to our Facebook</h1>';
				}


			}
		

			?>
			<!-- error message -->

		<section class="container-fluid main_area">
			<div class="container">
				<div class="row ">
					<div class="col-lg-6  ">
						<div class="main_items">
							<p>Facebook helps you connect and share with the people in your life.</p>
							<div class="main_img">
								<img src="img/main.png" alt="main">
							</div>
						</div>
					</div>
					<div class="col-lg-5 offset-1">
						<div class="s_title">
							<h2>Create an account</h2>
							<h4>It's free and always will be.</h4>
						</div>
						<form action="inc/reg.php" method="post" enctype="multipart/form-data" class="form-row s_form">	
							<div class="col">
								<input type="text" class="form-control" name="first_name" placeholder="First name" >
							</div>
							<div class="col">
								<input type="text"  class="form-control" name="sure_name" placeholder="Surname" >
							</div>
							<div class="col-lg-12">
								<input type="email"  class="form-control" name="email" placeholder="Mobile number or email address" >
							</div>
							<div class="col-lg-12 mt-2">
								<input type="email"  class="form-control" name="re_email" placeholder="Re mobile number or email address" >
							</div>
							<div class="col-lg-12">
								<input type="password"  class="form-control" name="password" placeholder="New password" >
							</div>
							<div class="birthday">
								<h3>Birthday</h3>
								<div class="row">
									<div class="input-group ml-lg-3">
										<select name="day">
											<option selected="Day">Day</option>
											<option value="01">01</option>
											<option value="02">02</option>
											<option value="03">03</option>
											<option value="04">04</option>
											<option value="05">05</option>
										</select>
										<select name="month">
											<option selected="Month">Month</option>
											<option value="jan">jan</option>
											<option value="feb">feb</option>
											<option value="march">march</option>
											<option value="april">april</option>
											<option value="may">may</option>
										</select>
										<select name="year">
											<option selected="Year">Year</option>
											<option value="1990">1990</option>
											<option value="1991">1991</option>
											<option value="1992">1992</option>
											<option value="1993">1993</option>
											<option value="1994">1994</option>
										</select>	
										<span class="ml-sm-3"><a href="#">Why do I need to provide my date of birth?</a></span>						
									</div>																		
								</div>																					
							</div>					
							<div class="gender col-12 d-flex  mt-sm-3">
								<input type="radio" name="gender" value="female" id="female">
								<label for="female">female</label>
								<input type="radio" name="gender" value="male" id="male">
								<label for="male">male</label>
							</div>					
							<div class="row mt-2">
								<div class="col-12 d-block upload">
									<h3>Upload your Photo</h3>
								</div>
								<div class="col-12">
									<input type="file"  name="photos" id="">
								</div>
							</div>				
								<p class="click mt-2">By clicking Sign Up, you agree to our <a href="#" target="_blank" >Terms</a>, <a href="#" target="_blank" >Data Policy</a> and <a href="#" target="_blank" >Cookie Policy</a>. You may receive SMS notifications from us and can opt out at any time.</p>			
							<div class="submit_main">
								<input type="submit" value="Sign up">	
							</div>				
							<div class="create mt-lg-5 my-lg-0 my-md-3">
								<p><a href="#">Create a Page</a> for a celebrity, band or business.</p>
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>	
		
			<!-- Main area End from here -->
			<!-- Footer Area Started From Here -->

		<footer class="container footer_area">
			<div class="row mt-5  lang">
				<div class="col">
					<span>English (UK)</span>
					<a href="#">বাংলা</a>
					<a href="#">অসমীয়া</a>
					<a href="#">हिन्दी</a>
					<a href="#">नेपाली</a>
					<a href="#">Bahasa Indonesia</a>
					<a href="#">العربية</a>
					<a href="#">中文(简体)</a>
					<a href="#">Bahasa Melayu</a>
					<a href="#">Español</a>
					<a href="#">Português (Brasil)</a>
				</div>
			</div>
			<div class="row my-2">		
					<a href="#">Sign Up</a>
					<a href="#">Log In</a>
					<a href="#">Messenger</a>
					<a href="#">Facebook</a>
					<a href="#"> LiteFind</a>
					<a href="#">Friends</a>
					<a href="#">People</a>
					<a href="#">ProfilesPages</a>
					<a href="#"> Page categories</a>
					<a href="#">Places</a>
					<a href="#">Games</a>
					<a href="#">Locations</a>
					<a href="#">Marketplace</a>
					<a href="#">Groups</a>
					<a href="#">Instagram</a>
					<a href="#">Local</a>
					<a href="#">Fundraisers</a>
					<a href="#">About</a>
					<a href="#">Create Ad</a>
					<a href="#">Create Page</a>
					<a href="#">Developers</a>
					<a href="#">Careers</a>
					<a href="#">Privacy</a>
					<a href="#">Cookies</a>
					<a href="#">AdChoices</a>
					<a href="#">Terms</a>
					<a href="#">Account security</a>
					<a href="#">Login help</a>
					<a href="#">Help</a>
					<a href="#">Settings</a>
					<a href="#">Activity log</a>
		
			</div>
		</footer>
	
				<!-- Footer Area End From Here -->
			
			<!-- Optional JavaScript -->
			<!-- jQuery first, then Bootstrap JS -->

			<script src="js/jquery-min.js"></script>
			<script src="js/bootstrap.bundle.js"></script>
			<script src="js/custom.js"></script>
	</body>
</html>