// for(var day = 0; day<10; day++){
//     console.log(day);
//     document.getElementById('day').innerHTML=day
    

// }


