<?php

    include('connect.php');
    session_start();
    $userName =  $_SESSION['first_name'].' '. $_SESSION['sure_name'] ;
    $userImg  = $_SESSION['userPhoto'];
    $postDate = date('F D, Y');
    $postContent = $_POST['postContent'];
    $postImg = $_FILES['postImg']['name'];
                $postTmpN = $_FILES['postImg']['tmp_name'];
    move_uploaded_file($postTmpN,'postImg/'.$postImg);

    if ($postContent || $postImg) {

        mysqli_query($connect," INSERT INTO user_post (userName, userImg, postDate, postContent, postImg) VALUES ('$userName', '$userImg', '$postDate', '$postContent', '$postImg');");
        header('location: ../home/home.php');
    }
    else{
        header('location: ../home/home.php');
    }