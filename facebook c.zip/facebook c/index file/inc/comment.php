<?php

    session_start();

    include('connect.php');

     $userName =  $_SESSION['first_name'].' '. $_SESSION['sure_name'] ;
     $userImg  = $_SESSION['userPhoto'];
     $comment = $_POST['userComment'];
     $post_id = $_POST['postId'];


   if($comment){
        mysqli_query($connect,"INSERT INTO user_comment (userName, userImg, comment, post_id) VALUES ('$userName', '$userImg', '$comment', '$post_id');");

        header('location: ../home/home.php');

   }
   else{
         header('location: ../home/home.php?result=no-comment');
   }

