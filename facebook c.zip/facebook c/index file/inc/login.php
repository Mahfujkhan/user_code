<?php

    session_start();

    include('connect.php');
    $u_email    = $_POST['email'];
    $u_password = md5($_POST['password']);

   $user_login = mysqli_query($connect,"SELECT * FROM user_info WHERE user_email = '$u_email' AND user_password ='$u_password'");

   $user_num = mysqli_num_rows($user_login);

    $user_piece = mysqli_fetch_array($user_login);


   if ($user_num == 1) {

        $_SESSION['first_name'] = $user_piece['first_name']; 
        $_SESSION['sure_name'] = $user_piece['sure_name']; 
        $_SESSION['userPhoto']=$user_piece['userPhoto'];
        
         header('location: ../home/home.php');
   }
   else{

    echo '<h1 style="background:red;color:#fff; text-align:center;padding:20px; margin:0; ">invalid password and email please try again</h1>';

   }

