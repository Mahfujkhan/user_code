<?php

     include('connect.php');

     if(isset ($_GET['del'])){

        $delPostId = $_GET['del'];

        mysqli_query($connect," DELETE FROM user_post WHERE post_id = '$delPostId' ");

        echo '<script type="text/javascript">alert("Your post has been Delete")</script>';

        echo '<script type="text/javascript">window.open("../home/profile.php","_self")</script>';
     }


?>