<?php
    session_start();
    include('connect.php');

    if(isset($_GET['edit'])){

    $edit_id = $_GET['edit'];      
    $userName =  $_SESSION['first_name'].' '. $_SESSION['sure_name'] ;
    $userImg  = $_SESSION['userPhoto'];
    $postDate = date('F D, Y');
    
    $postContent = $_POST['postContent'];
    $postImg = $_FILES['postImg']['name'];
                $postTmpN = $_FILES['postImg']['tmp_name'];

        if($postContent=='' || $postImg==''){

            echo '<script type="text/javascript">alert("Please try again")</script>';

            echo '<script type="text/javascript">window.open("../home/profile.php","_self")</script>';

            exit();

        }
        else{

            move_uploaded_file($postTmpN,'postImg/'.$postImg);

            mysqli_query($connect," UPDATE user_post SET postContent = '$postContent', postImg = '$postImg' WHERE post_id = '$edit_id' ");


             echo '<script type="text/javascript">alert("Success Your Post updated")</script>';

            echo '<script type="text/javascript">window.open("../home/profile.php","_self")</script>';

        }

    }
