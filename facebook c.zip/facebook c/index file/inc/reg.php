<?php


       include('connect.php');

        $first_name    = $_POST['first_name'];
        $sure_name     = $_POST['sure_name'];
        $user_email    = $_POST['email'];
                         $re_email  = $_POST['re_email'];
        $user_password = md5($_POST['password']);
        $birthday      = $_POST['day'].'/'. $_POST['month'].'/'.$_POST['year'];
        $gender        = $_POST['gender'];

        $userPhoto   = $_FILES['photos']['name'];
                         $tmp   = $_FILES['photos']['tmp_name'];
        move_uploaded_file($tmp,'profile/'.$userPhoto);


        $user_m =mysqli_query($connect,"SELECT * FROM user_info WHERE user_email ='$user_email'");

        $email_number = mysqli_num_rows($user_m);

        if ($first_name && $sure_name && $user_email && $user_password && $birthday &&  $gender && $userPhoto) {

           if ($user_email == $re_email) { 

                if($email_number >= 1){

                    header('location: ../index.php?result=Already-You-have-an-account');

                }else{

                    mysqli_query($connect,"INSERT INTO user_info (first_name, sure_name, user_email, user_password, birthday, gender, userPhoto) VALUES ('$first_name', '$sure_name', '$user_email', '$user_password', '$birthday', '$gender', '$userPhoto');");

                    header('location: ../index.php?result=ok');
                    
                }

            }else{
      
                 header('location: ../index.php?result=Your-email-is-not-math');
             }

        }else{
           
                header('location: ../index.php?result=empty-box');
        }

        
      


