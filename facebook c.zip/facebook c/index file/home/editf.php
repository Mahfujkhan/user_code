<?php

    session_start();

    if (!isset ($_SESSION['first_name'])) {
        header('location: ../index.php');
    }

    $total_name =  $_SESSION['first_name'].' '. $_SESSION['sure_name'] ;


?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title> <?php echo $total_name?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="img/fav icon/favicon.ico" type="image/x-icon"/>
        <!--=== Bootstrap ===-->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!--=== Main Css ===-->
        <link rel="stylesheet" href="css/style.css">
        <!--=== Fontawesome icon ===-->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!--=== Responsive Css ===-->
        <link rel="stylesheet" href="css/responsive.css">
    </head>
    <body style="background: #E9EBEE;"  >
            <!--[if lt IE 8]>
                <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
            <![endif]-->
            <!--===============================================================================-->
            <!-- `modal box start -->
            <div id="display_modal">
                <img src="" class="modal_img" alt="">
                <div class="close_m">X</div>
            </div>
            <!-- `modal box end -->
            
            <!--====== Header Start ======-->
        <header class="container-fluid pl-3">
            <div id="menu">
                 <i class="fa fa-navicon" aria-hidden="true"></i>
                    </div>
                <div id="close">
                    X
                </div>     
            <nav class="navbar p-0  navbar-expand-lg navbar-light ml-5">  
                    <a class="logo" href="#"><i class="fa fa-facebook-square"></i></a>                     
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <div class="input-group ml-1 ">
                        <input type="search" placeholder="Search" aria-label="Search" aria-describedby="button-addon2">
                        <div class="input-group-append search_box">
                            <button class="btn btn-outline-secondary " type="submit" id="button-addon2"><i class="fa fa-search"></i></button>
                        </div>
                    </div> 
                    <ul class="navbar-nav mt-2 mt-lg-0 mr-2 nav_menu">
                        <li><span class="user"><img src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user"> <a class="pl-0 ml-1 home_m" href="#"><?php echo $_SESSION['first_name'];?></a></span> </li>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Create</a> </li>
                    </ul>  
                    <ul class="icon" >
                        <li><a href="#"><i class="fa fa-user"></i></a></li>
                        <li><a href="#"><i class="fa fa-inbox"></i></a></li>
                        <li><a href="#"><i class="fa fa-bell"></i></a></li>
                        <li><a href="#"><i class="fa fa-question-circle"></i></a></li>
                        <li><a href="#"><i class="fa fa-caret-down down "></i></a>
                            <div class="row d_menu bg-white py-2 ">
                                <div class="col-12">
                                    <h5>Your Pages:</h5>
                                </div>
                                <div class="col-12 py-1">
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Jahed hossain bhuiyan</a></span>
                                </div>
                                <div class="col-12 py-1">
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Bangladesh Cricket</a></span>
                                </div>
                                <div class="col-12 py-1">
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Raju store</a></span>
                                </div>
                                <div class="col-12">
                                    <a class="pl-0" href="#">See more</a>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <h5>Business Manager:</h5>
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Techtunes</a></span>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <a href="#">Manage Pages</a>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <a href="#">New Group</a>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <a href="#">Advertising on Facebook</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="#">Activity log</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="#">News feed preferences</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="#">Settings</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="../inc/logout.php">Log out</a>
                                </div>
                            </div>
                        </li>
                    </ul>        
                </div>
            </nav>
        </header>
            <!--====== Header End ======-->
            <!--====== Main section Started ======-->
        <section class="main_content" id="main_content" >
            <div class="row">
                <!-- content_one_start -->
                <div class=" col-lg-3 col-md-12 content_one" id="content_one" >  
                    <div class="row">
                        <div class="col-12 p-0" >
                            <span class="user" > <img  src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user"> <a  href="#"><?php echo $total_name?></a></span>
                        </div>
                    </div>
                    <div class="row my-2 news_feed" >      
                        <div class="col-8 pl-0">
                            <i class="fa fa-newspaper-o"></i>
                            <a class="ml-2" href="#">News Feed</a>
                        </div> 
                        <div class="col-4 pl-0 text-right">
                            <a href="#">...</a>
                        </div> 
                        <div class="col-12 pl-0">
                            <i class="fa fa-inbox"></i>
                            <a class="ml-2" href="#">Messenger</a>
                        </div>
                        <div class="col-6 pl-0">
                            <i class="fa fa-tv text-primary"></i>
                            <a class="ml-2" href="#">Watch</a>
                        </div>
                        <div class="col-6  pl-0 text-right">
                            <a href="#">...</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 p-0">
                            <h5>shortcut</h5>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user" ><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">MULTIsoft IT BOND...</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Md Niloy.bd</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Bangladesh Cricket</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Jahed hossain bhuiyan</a></span>
                        </div>
                        <div class="col-12 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Lorem Ipsum |...</a></span>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12 p-0 ">
                            <h5>explore</h5>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Saved</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Pages</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Events</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Friends list</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">memories</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Se more</a></span>
                        </div>                
                    </div>   
                </div>
                    <!-- content_one_end -->
                    <!-- content_two_started -->    
                <div class="col-lg-4 mt-3  content_two" id="content_two" >        
        
                    <?php
                    
                    include('../inc/connect.php');

                    if(isset($_GET['edit'])):

                    $EditPostId = $_GET['edit'];
                    
                    $all_post = mysqli_query($connect,"SELECT * FROM user_post WHERE post_id = '$EditPostId' ");
                    
                    while($post_piece =mysqli_fetch_array($all_post)): 

                    $post_id = $post_piece['post_id'];
                    $edit_post_content =  $post_piece['postContent'];
                    $edit_post_img =  $post_piece['postImg'];    

                    ?>

                    <form action="../inc/edit.php?edit=<?php echo $post_id ;?>" method="post" enctype="multipart/form-data" >
                        <div class=" row post_area">
                            <div class="col-6 py-1 p-0 pl-1 post_title ">
                                <h5>Create Post</h5>
                            </div>
                            <div class="col-6 py-1 text-right post_title ">
                                <span class="p_close" >X</span>
                            </div>
                            <div class="col-2 text-center mt-2 p-0">
                                <img class="user"  src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user">
                            </div>
                            <div class="col-10 p-0 text_area" >
                                <textarea name="postContent" class="col-12 p-0 border-0" placeholder="Edit your post"><?php echo $edit_post_content; ?></textarea>
                            </div>
                            <div class="col-12 py-3 bg-info border border-danger">
                                <img class="img-fluid" src="../inc/postImg/<?php echo $edit_post_img ; ?>" alt="">
                            </div>
                            <div class="col-12 my-2 border-top pt-2">
                                <ul class="d-flex" >
                                    <li>
                                        <span class="in_p" ><i class="fa fa-picture-o mr-2"></i><input style="width: 0px;" type="file" name="postImg" placeholder="Photo/Video ">Photo/Video></span>
                                    </li>
                                    <li>
                                        <span><i class="fa fa-tag mr-2"></i>Tag friends</span>   
                                    </li>
                                    <li>
                                        <span> <i class="fa fa-tag mr-2"></i>Feeling/Activity</span>
                                    </li>
                                     <li>
                                        <a href="#">...</a>
                                    </li>
                                </ul>
                            </div>
                        </div>  
                        <div class="row py-1 bg-light share_area">
                            <div class="col-6 my-2">
                                <span class="user"><img src="img/user.jpg" alt="user"> News Feed</span>
                            </div>
                            <div class="col-6 my-2 text-right">
                                <select name="pub">
                                    <option selected="public">public</option>
                                    <option value="friend">firend</option>
                                    <option value="only me">only me</option>
                                </select>
                            </div>
                            <div class="col-6 my-2">
                                <span class="user"><img src="img/user.jpg" alt="user"> Your Story</span>
                            </div>
                            <div class="col-6 my-2 text-right">
                                <select name="pub">
                                    <option selected="public">public</option>
                                    <option value="friend">firend</option>
                                    <option value="only me">only me</option>
                                </select>
                            </div>
                            <div class="col-12 bg-primary text-white text-center py-1">
                             <input class="border-0 bg-primary text-white "  type="submit" value="Update Your post">
                            </div>
                        </div> 
                    </form>


                    <?php endwhile;
                    endif;
                    ?>
                   
           
                </div> 
                 <!-- content_two_end -->
                 <!-- content_three_started -->
                <div class=" col-lg-3 mt-3  content_three">
                   
                </div>
                 <!-- content_three_end -->
                 <!-- content_four_started -->
                 <div class=" col-lg-2 mt-3  content_four">
                <div class="row">
                    <div class="col-6 pl-1 mt-2">
                        <p>Your Page</p>
                    </div>
                    <div class="col-6 pl-1 mt-2 text-right">
                        <p>See all</p>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Jahed Hossain Bhuiyan</a><span class="bg-white ml-2 number">1</span></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Cricinfo Bangladesh</a><span class="bg-white ml-2 number">1</span></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">মেহেদী আই.টি সেন্টার</a><span class="bg-white ml-2 number">1</span></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                      <p>Contacts</p>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Md monju</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Mamun Khan</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Piclu Khan</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Md Su Sohel</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Kazi Lutfur Rahman</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Habib Khan</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Md salauddin jibon</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>


                </div>
                 </div>
                 <!-- content_four_end -->
                
            </div>
        </section>
            <!--====== Main section End ======-->
        <!--==================================================================-->
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

        <!--=== All Plugin ===-->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/fonts5.min.js"></script>

        <!--=== All Active ===-->
        <script type="text/javascript" src="js/main.js"></script>
    </body>
</html>