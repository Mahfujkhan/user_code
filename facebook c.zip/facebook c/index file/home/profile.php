<?php

    session_start();

    if (!isset ($_SESSION['first_name'])) {
        header('location: ../index.php');
    }

    $total_name =  $_SESSION['first_name'].' '. $_SESSION['sure_name'] ;


?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title> <?php echo $total_name?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="img/fav icon/favicon.ico" type="image/x-icon"/>
        <!--=== Bootstrap ===-->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!--=== Main Css ===-->
        <link rel="stylesheet" href="css/style.css">
        <!--=== Fontawesome icon ===-->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!--=== Responsive Css ===-->
        <link rel="stylesheet" href="css/responsive.css">
    </head>
    <body >
            <!--[if lt IE 8]>
                <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
            <![endif]-->
            <!--===============================================================================-->
            <!-- `modal box start -->
            <div id="display_modal">
                <img src="" class="modal_img" alt="">
                <div class="close_m">X</div>
            </div>
            <!-- `modal box end -->
            
            <!--====== Header Start ======-->
        <header class="container-fluid pl-3">
            <div id="menu">
                 <i class="fa fa-navicon" aria-hidden="true"></i>
                    </div>
                <div id="close">
                    X
                </div>     
            <nav class="navbar p-0  navbar-expand-lg navbar-light ml-5">  
                    <a class="logo" href="#"><i class="fa fa-facebook-square"></i></a>                     
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <div class="input-group ml-1 ">
                        <input type="search" placeholder="Search" aria-label="Search" aria-describedby="button-addon2">
                        <div class="input-group-append search_box">
                            <button class="btn btn-outline-secondary " type="submit" id="button-addon2"><i class="fa fa-search"></i></button>
                        </div>
                    </div> 
                    <ul class="navbar-nav mt-2 mt-lg-0 mr-2 nav_menu">
                        <li><span class="user"><img src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user"> <a class="pl-0 ml-1 home_m" href="#"><?php echo $_SESSION['first_name'];?></a></span> </li>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Create</a> </li>
                    </ul>  
                    <ul class="icon" >
                        <li><a href="#"><i class="fa fa-user"></i></a></li>
                        <li><a href="#"><i class="fa fa-inbox"></i></a></li>
                        <li><a href="#"><i class="fa fa-bell"></i></a></li>
                        <li><a href="#"><i class="fa fa-question-circle"></i></a></li>
                        <li><a href="#"><i class="fa fa-caret-down down "></i></a>
                            <div class="row d_menu bg-white py-2 ">
                                <div class="col-12">
                                    <h5>Your Pages:</h5>
                                </div>
                                <div class="col-12 py-1">
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Jahed hossain bhuiyan</a></span>
                                </div>
                                <div class="col-12 py-1">
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Bangladesh Cricket</a></span>
                                </div>
                                <div class="col-12 py-1">
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Raju store</a></span>
                                </div>
                                <div class="col-12">
                                    <a class="pl-0" href="#">See more</a>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <h5>Business Manager:</h5>
                                    <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Techtunes</a></span>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <a href="#">Manage Pages</a>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <a href="#">New Group</a>
                                </div>
                                <div class="col-12 py-1  border ">
                                    <a href="#">Advertising on Facebook</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="#">Activity log</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="#">News feed preferences</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="#">Settings</a>
                                </div>
                                <div class="col-12 py-1">
                                    <a href="../inc/logout.php">Log out</a>
                                </div>
                            </div>
                        </li>
                    </ul>        
                </div>
            </nav>
        </header>
            <!--====== Header End ======-->
            <!--====== Main section Started ======-->
        <section class="main_content" id="main_content" >
            <div class="row">
                <!-- content_one_start -->
                <div class=" col-lg-3 col-md-12 content_one" id="content_one" >  
                    <div class="row">
                        <div class="col-12 p-0" >
                            <span class="user" > <img  src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user"> <a  href="#"><?php echo $total_name?></a></span>
                        </div>
                    </div>
                    <div class="row my-2 news_feed" >      
                        <div class="col-8 pl-0">
                            <i class="fa fa-newspaper-o"></i>
                            <a class="ml-2" href="#">News Feed</a>
                        </div> 
                        <div class="col-4 pl-0 text-right">
                            <a href="#">...</a>
                        </div> 
                        <div class="col-12 pl-0">
                            <i class="fa fa-inbox"></i>
                            <a class="ml-2" href="#">Messenger</a>
                        </div>
                        <div class="col-6 pl-0">
                            <i class="fa fa-tv text-primary"></i>
                            <a class="ml-2" href="#">Watch</a>
                        </div>
                        <div class="col-6  pl-0 text-right">
                            <a href="#">...</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 p-0">
                            <h5>shortcut</h5>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user" ><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">MULTIsoft IT BOND...</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Md Niloy.bd</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Bangladesh Cricket</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Jahed hossain bhuiyan</a></span>
                        </div>
                        <div class="col-12 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Lorem Ipsum |...</a></span>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12 p-0 ">
                            <h5>explore</h5>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Saved</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Pages</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Events</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Friends list</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">memories</a></span>
                        </div>
                        <div class="col-12 my-1 p-0">
                            <span class="user"><img src="img/15x15.png" alt="img"> <a class="pl-0" href="#">Se more</a></span>
                        </div>                
                    </div>   
                </div>
                    <!-- content_one_end -->
                    <!-- content_two_started -->    
                <div class="col-lg-4 mt-3  content_two" id="content_two" >        
                    <form action="../inc/post.php" method="post" enctype="multipart/form-data" >
                        <div class=" row post_area">
                            <div class="col-6 py-1 p-0 pl-1 post_title ">
                                <h5>Create Post</h5>
                            </div>
                            <div class="col-6 py-1 text-right post_title ">
                                <span class="p_close" >X</span>
                            </div>
                            <div class="col-2 text-center mt-2 p-0">
                                <img class="user"  src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user">
                            </div>
                            <div class="col-10 p-0 text_area" >
                                <textarea name="postContent" class="col-12 p-0 border-0" placeholder="What's on your mind"></textarea>
                            </div>
                            <div class="col-12 my-2 border-top pt-2">
                                <ul class="d-flex" >
                                    <li>
                                        <span class="in_p" ><i class="fa fa-picture-o mr-2"></i><input style="width: 0px;" type="file" name="postImg" placeholder="Photo/Video ">Photo/Video></span>
                                    </li>
                                    <li>
                                        <span><i class="fa fa-tag mr-2"></i>Tag friends</span>   
                                    </li>
                                    <li>
                                        <span> <i class="fa fa-tag mr-2"></i>Feeling/Activity</span>
                                    </li>
                                     <li>
                                        <a href="#">...</a>
                                    </li>
                                </ul>
                            </div>
                        </div>  
                        <div class="row py-1 bg-light share_area">
                            <div class="col-6 my-2">
                                <span class="user"><img src="img/user.jpg" alt="user"> News Feed</span>
                            </div>
                            <div class="col-6 my-2 text-right">
                                <select name="pub">
                                    <option selected="public">public</option>
                                    <option value="friend">firend</option>
                                    <option value="only me">only me</option>
                                </select>
                            </div>
                            <div class="col-6 my-2">
                                <span class="user"><img src="img/user.jpg" alt="user"> Your Story</span>
                            </div>
                            <div class="col-6 my-2 text-right">
                                <select name="pub">
                                    <option selected="public">public</option>
                                    <option value="friend">firend</option>
                                    <option value="only me">only me</option>
                                </select>
                            </div>
                            <div class="col-12 bg-primary text-white text-center py-1">
                             <input class="border-0 bg-primary text-white "  type="submit" value="Share">
                            </div>
                        </div> 
                    </form>
                    <?php
                    
                    include('../inc/connect.php');
                    
                    $all_post = mysqli_query($connect,"SELECT * FROM user_post WHERE userName='$total_name' ORDER BY post_id DESC");
                    
                    while($post_piece =mysqli_fetch_array($all_post)): 
                    $post_id = $post_piece['post_id']; ?>

                        <div class="row mt-3 bg-white">
                            <div class="col-6 p-lg-0  d-flex align-items-end">
                                <img class="user ml-2 mt-2 " src="../inc/profile/<?php echo $post_piece['userImg']; ?>" alt="user">
                                <div class="ml-2">
                                    <a class="pl-0 user_name" href="#"><?php echo $post_piece['userName']; ?></a>
                                <div class="d-flex align-items-center">
                                        <p class="mr-2" style="font-size:12px;"><?php  echo $post_piece['postDate']; ?></p> 
                                    <span> <i class="fas fa-user-friends n_icon"></i></span>
                                </div>
                                </div>
                            </div>
                            <div class="col-6 p-0">
                                <div class="text-right n_right ">
                                    <a class="d-block mt-1"  href="../inc/delete.php?del=<?php echo $post_id; ?>">delete</a>
                                    <a class="d-block mt-1"  href="editf.php?edit=<?php echo $post_id; ?>">Edit post</a>
                                </div>
                            </div>
                            <div class="col-lg-12  mt-2 ">                 
                            <p><?php echo $post_piece['postContent']; ?></p>              
                            </div>
                            <div class="col-lg-12 p-0 mt-2 ">                 
                                <img src="../inc/postImg/<?php echo $post_piece['postImg']; ?>" class=" img-fluid main_img" alt="jpg">                
                            </div>
                            <div class=" col-12 like_area">
                                <div class="row justify-content-around bg-white">
                                    <div class="col-3 justify-content-center py-2 d-flex  align-items-center hover_l">
                                        <i class="fa fa-hand-o-right" ></i>
                                        <p class="ml-2" >Like</p>
                                    </div>
                                    <div class="col-3 justify-content-center py-2 d-flex  align-items-center hover_l">
                                        <i class=" fa fa-comment-o"></i>
                                        <p class="ml-2">Comment</p>
                                    </div>
                                    <div class="col-3 justify-content-center py-2 d-flex  align-items-center hover_l">
                                        <i class="fa fa-share " ></i>
                                        <p class="ml-2">Share</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 pt-2 pb-2 pl-2 pr-0 comment_box ">
                                <form action="../inc/comment.php" method="post">
                                    <div d-flex >
                                        <img src="../inc/profile/<?php echo $_SESSION['userPhoto']?>" alt="user"> 
                                        <input class="ml-1" type="text" name="userComment" placeholder="Write a comment...">
                                        <input type="hidden" name="postId" value="<?php echo $post_id; ?>">
                                        <h6>Press Enter to post</h6>
                                        <!-- error messages -->
                                        <div class="col-12">
                                            <?php
                                                if(isset($_GET['result'])){
                                                    if ($_GET['result'] == 'no-comment') {
                                                        echo '<p style="background:red;color:#fff; text-align:center;padding:5px 0px;border-radius: 20px; margin:0; ">No Comment</p>';
                                                    }
                                                }                             
                                            ?>
                                        </div>
                                        <!-- error messages -->
                                    </div>
                                </form>
                                <?php

                                   $all_comment = mysqli_query($connect,"SELECT * FROM user_comment WHERE post_id = '$post_id' ORDER BY comment_id DESC");

                              while( $comment_piece = mysqli_fetch_array($all_comment)):  ?>

                              <div class="col-12 pl-1 mt-2" >
                           <div class="d-flex">
                           <img class="mt-0" src="../inc/profile/<?php echo $comment_piece['userImg']; ?>" alt="user">
                               <div class="ml-2">
                                    <a href="#"><?php echo $comment_piece['userName']; ?></a> 
                                    <p><?php echo $comment_piece['comment']; ?></p>
                               </div>
                           </div>
                              </div>
                              <?php endwhile ; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                   
           
                </div> 
                 <!-- content_two_end -->
                 <!-- content_three_started -->
                <div class=" col-lg-3 mt-3  content_three">
                    <div class="row bg-white story">
                        <div class="col-6 mt-2 pl-2 p-0">
                            <h5>Stories</h5>
                        </div>
                        <div class="col-6 mt-2 p-0 pr-2 text-right">
                            <a class="mr-3" href="#">Archive</a>
                            <a href="#">Settings</a>
                        </div>
                        <div class="col-12 my-2">
                            <div class="d-flex align-items-center">
                            <img class="user" src="img/50x50.png"  alt="img">
                            <div class="ml-2" >
                            <a href="#">Add to your Story</a>
                            <p>Share a photo, video or write something</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-12 my-2">
                            <div class="d-flex align-items-center">
                            <img class="user" src="img/50x50.png"  alt="img">
                            <div class="ml-2" >
                            <a href="#"> Lipon Sikder Soton</a>
                            <p>a few seconds ago</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-12 my-2">
                            <div class="d-flex align-items-center">
                            <img class="user" src="img/50x50.png"  alt="img">
                            <div class="ml-2" >
                            <a href="#">Anik Kumar Nath</a>
                            <p>3 hours ago</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-12 p-0 pl-4 mb-2">
                            <span class="mr-2" ><i class="fas fa-caret-down"></i></span> <a href="#">See More</a>
                        </div>
                    </div>
                    <div class="row bg-white my-3 py-2">
                        <div class="col-12">
                            <span><i class="fas fa-box"></i></span><a href="#">KH Shubo</a><span class="mx-2">and</span><a href="#">3 others</a>
                        </div>
                        <div class="col-12">
                            <span><i class="fas fa-box"></i></span><a href="#">1 new saved videos</a><span class="mx-2">in the last week</span>
                        </div>
                    </div>
                    <div class="row bg-white ">
                        <div class="col-6 py-2 border-bottom ">
                            <div class="d-flex">
                            <p class="font-weight-bold" >Your Pages(2)</p>
                            <i class="fas fa-caret-down ml-2"></i>
                            </div>   
                        </div>
                        <div class="col-6 py-2 text-right border-bottom ">
                             <a href="#">...</a>
                        </div>
                        <div class="col-12 py-2">
                            <div class="d-flex align-items-center">
                            <img class="user" src="img/50x50.png" class="mr-2" alt="img">
                            <div class="ml-2 text-center" >
                            <a href="#">Cricinfo Bangladesh</a>
                            <p>Messages</p>
                            <p> <span><i class="fa fa-address-book" aria-hidden="true"></i></span> Notifications</p>
                            </div>
                            </div>
                        </div>
                        <div class="row py-2 justify-content-around publish">
                            <div class="col-2 " >          
                            <i class="fa fa-camera-retro" aria-hidden="true"></i>
                            <a href="#">Publish</a>   
                            </div>
                            <div class="col-2" >
                            <i class="fa fa-camera-retro" aria-hidden="true"></i>
                            <a href="#">photo</a>
                            </div>
                            <div class="col-2" >
                            <i class="fa fa-camera-retro" aria-hidden="true"></i>
                            <a href="#">live</a>
                            </div>
                            <div class="col-2" >
                            <i class="fa fa-camera-retro" aria-hidden="true"></i>
                            <a href="#">invite</a>     
                            </div>
                        </div>
                        <div class="row my-2 justify-content-around  li_vi ">
                            <div class="col-12 d-flex">
                            <p class="font-weight-bold" style="background-color: #dddfe2;" >Likes</p>
                            <p>Views</p>
                            <p>Posts</p>
                            </div>
                        </div>          
                        <div class="col-12 text-center">
                             <p>5,176</p>
                             <p style="color: #42b72a;" > 67 new likes this week</p>
                        </div>   
                        <div class="row border-bottom" style="margin:0 auto;" >
                            <div class="col-12 my-2 d-flex ">
                            <img class="user" src="img/50x50.png" alt="img">
                            <img class="user" src="img/50x50.png" alt="img">
                            <img class="user" src="img/50x50.png" alt="img">
                            <img class="user" src="img/50x50.png" alt="img">
                            <img class="user" src="img/50x50.png" alt="img">
                            <img class="user" src="img/50x50.png" alt="img">
                            </div>
                        </div>    
                        <div class="row my-2" style="margin:0 auto;" >
                            <div class="col-12" style="display:flex;" >        
                            <span><i class="fa fa-magnet" aria-hidden="true"></i></span>  <p>create promotion</p>         
                            <span><i class="fa fa-caret-down"></i></span>
                            </div> 
                        </div>            
                    </div>
                    <div class="row my-2 py-2 bg-white">
                        <div class="col-6 py-2">
                            <p style="font-size:13px;" >People You May Know</p>
                        </div>
                        <div class="col-6 py-2 text-right">
                            <a href="#">See all</a>
                        </div>
                        <div class="col-12">
                            <div class="d-flex" >
                                <img class="user" src="img/50x50.png" alt="img">
                                <div class="ml-2">
                                    <a href="#">Farayezi Sazib </a><span>(কালাইয়া)</span>
                                    <p>Saif Bhuiyan is a mutual friend.</p>
                                    <div class="py-2" >
                                      <button>  <span><i class="fa fa-user"></i></span>  Add friend</button>
                                        <button>Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row bg-white">
                        <div class="col-6 py-2">
                            <p style="font-size:13px;" >Suggested Pages</p>
                        </div>
                        <div class="col-6 py-2 text-right">
                            <a href="#">See all</a>
                        </div>
                        <div class="col-12 py-1 border-info">
                            <a href="#">Hasan</a><span class="ml-2" >likes this.</span>
                        </div>
                        <div class="d-flex ml-3" >
                            <img  class="user" src="img/50x50.png" alt="img">
                           <div class="ml-2" >
                                <a href="#">Nishan Ahammed Neon</a>
                            <p>Public Figure</p>
                           </div>
                        </div>
                        <div class="col-12 py-1">
                            <img class="img-fluid" src="img/thummail.jpg" alt="">
                        </div>
                        <div class="col-12 py-2 text-center">
                            <span><i class="fa fa-life-bouy" aria-hidden="true"></i>Like page</span>
                        </div>
                    </div>
                    <div class="row my-3  py-2 bg-white">
                        <div class="col-10">
                            <span>English (US)  </span>              
                            <a href="#">বাংলা</a>
                            <a href="#"> অসমীয়া</a>
                            <a href="#">Español</a> 
                            <a href="#">Português (Brasil)</a>       
                        </div>
                        <div class="col-2">
                            <button>+</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <a href="#">Privacy</a>
                            <a href="#">Terms</a>
                            <a href="#">Advertising</a>
                            <a href="#">Ad Choices</a>
                            <a href="#">Cookies</a>
                            <a href="#">More</a>
                        </div>
                        <div class="col-12">
                            <p>Facebook © 2019</p>
                        </div>
                    </div>
                </div>
                 <!-- content_three_end -->
                 <!-- content_four_started -->
                 <div class=" col-lg-2 mt-3  content_four">
                <div class="row">
                    <div class="col-6 pl-1 mt-2">
                        <p>Your Page</p>
                    </div>
                    <div class="col-6 pl-1 mt-2 text-right">
                        <p>See all</p>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Jahed Hossain Bhuiyan</a><span class="bg-white ml-2 number">1</span></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Cricinfo Bangladesh</a><span class="bg-white ml-2 number">1</span></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">মেহেদী আই.টি সেন্টার</a><span class="bg-white ml-2 number">1</span></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                      <p>Contacts</p>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Md monju</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Mamun Khan</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Piclu Khan</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Md Su Sohel</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Kazi Lutfur Rahman</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Habib Khan</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Md salauddin jibon</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>
                    <div class="col-12 pl-1 my-1">
                        <span class="chat_man"><img class="chat" src="img/35x35.png" alt="img"><a class="ml-2" href="#">Rupa Antor</a></span>
                    </div>


                </div>
                 </div>
                 <!-- content_four_end -->
                
            </div>
        </section>
            <!--====== Main section End ======-->
        <!--==================================================================-->
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

        <!--=== All Plugin ===-->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/fonts5.min.js"></script>

        <!--=== All Active ===-->
        <script type="text/javascript" src="js/main.js"></script>
    </body>
</html>