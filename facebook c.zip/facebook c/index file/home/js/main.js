$(document).ready(function($){
    // Post Area
    $('textarea').click(function(){
        $('.share_area').css('display','flex');
        $('textarea').css('font-size','30px');
        $('.p_close').css('display','block');
    });

    $('.p_close').click(function(){
        $('.share_area').css('display','none');
        $('.p_close').css('display','none');
        $('textarea').css('font-size','12px');
    });
    // Post Area
    // D menu Show
    $('.down').click(function(){
        $('.d_menu').fadeToggle(1000);
         return false ;
    });
    $('body').click(function(){
        $('.d_menu').hide();
    });
    // D menu Show



}(jQuery));

// Side nav
var mainContent = document.getElementById('main_content');
var contentOne = document.getElementById('content_one');
var contentTwo = document.getElementById('content_two');
var open = document.getElementById('menu');
var close = document.getElementById('close');


open.addEventListener('click',function(){

    contentOne.style.left = '0px';
    contentTwo.style.marginLeft ='20%';
    open.style.display = 'none';
    close.style.display = 'block';
   
});

close.addEventListener('click',function(){

    contentOne.style.left = '-250px';
    contentTwo.style.marginLeft ='2%';
    open.style.display = 'block';
    close.style.display = 'none';
});

// Side nav

// modal_box
 var mainImg = document.querySelectorAll('.main_img');
 var modalImg = document.querySelector('.modal_img');
 var closeM = document.querySelector('.close_m');

 for (let i = 0; i < mainImg.length; i++) {

    mainImg[i].addEventListener('click',function(){
        document.getElementById('display_modal').style.display = 'block';
        modalImg.src = mainImg[i].src;
    }) 
 }
closeM.addEventListener('click',function () {
    document.getElementById('display_modal').style.display = 'none';

});
// modal_box
